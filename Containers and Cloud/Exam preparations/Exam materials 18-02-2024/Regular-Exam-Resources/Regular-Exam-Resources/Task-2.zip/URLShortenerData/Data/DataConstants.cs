﻿namespace URLShortenerData.Data
{
    public class DataConstants
    {
        public const int OriginalUrlMaxLenght = 150;
        public const int OriginalUrlMinLenght = 2;

        public const int ShortUrlMaxLenght = 150;
        public const int ShortUrlMinLenght = 2;
    }
}
